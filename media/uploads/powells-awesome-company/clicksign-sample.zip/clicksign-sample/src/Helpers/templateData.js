function getTemplateData(contract) {
  const { Property, Tenants, Landlords } = contract;
  const PropertyAddress = Property.Address;
  const formattedAddress = `${PropertyAddress.Address}, ${
    PropertyAddress.StreetNumber
  }${PropertyAddress.Complement ? `, ${PropertyAddress.Complement}` : ""}\n${
    PropertyAddress.Neighbourhood
  }, ${PropertyAddress.City}, ${PropertyAddress.State}\nCEP: ${
    PropertyAddress.PostalCode
  }`;

  const landlordHeader = _formatLandlordHeader(Landlords);
  const tenantHeader = _formatTenantHeader(Tenants);

  const rentalValue = _formatCurrency(contract.Price);
  const iptuValue = _formatCurrency(contract.IptuValue);
  const condominiumValue = _formatCurrency(contract.CondominimumValue);
  const readjustmentIndex = contract.ReadjustmentIndex;
  const startDate = contract.StartDate;
  const endDate = contract.EndDate;
  const parkingSpaces = contract.Property.ParkingSpaces;

  return {
    tenantHeader,
    landlordHeader,
    address: formattedAddress,
    rentalValue,
    condominiumValue,
    iptuValue,
    readjustmentIndex,
    parkingSpaces,
    startDate,
    endDate,
  };
}

const _formatLandlordHeader = (landlords) => {
  let landlordHeader = "";
  console.log(landlords[0].Person.IsLegalEntity);
  if (landlords[0].Person.IsLegalEntity) {
    landlordHeader = `\t${landlords[0].Person.Name}, CNPJ: ${landlords[0].Person.IdentificationNumber}\n`;
    landlordHeader += "\tRepresentada por seu(s) sócios(s):\n";
    landlords[0].Person.LegalRepresentatives.forEach(
      (legalRepresentative, index) => {
        landlordHeader += `\t\t${legalRepresentative.Name}, CPF: ${
          legalRepresentative.IdentificationNumber
        }${
          index === landlords[0].Person.LegalRepresentatives.length - 1
            ? ""
            : ",\n"
        }`;
      }
    );
  } else {
    landlords.forEach((landlord, index) => {
      landlordHeader += `\t${landlord.Name}, CPF: ${
        landlord.IdentificationNumber
      }${index === landlords.length - 1 ? "" : ",\n"}`;
    });
  }
  return landlordHeader;
};

const _formatTenantHeader = (tenants) => {
  let tenantHeader = "";
  tenants.forEach((tenant, index) => {
    tenantHeader += `\t${tenant.Person.Name}, CPF: ${
      tenant.Person.IdentificationNumber
    }${index === tenants.length - 1 ? "" : ",\n"}`;
  });
  return tenantHeader;
};

const _formatCurrency = (value) => {
  if (!value) return "-";
  return "R$" + value.toFixed(2).replace(".", ",");
};

module.exports = {
  getTemplateData,
};
