const axios = require("axios");

async function createDocument(documentPath, templateId, templateData) {
  const token = process.env.CLICKSIGN_API_TOKEN;
  console.log(templateData);

  const options = {
    method: "POST",
    url: `https://sandbox.clicksign.com/api/v2/templates/${templateId}/documents`,
    params: { access_token: token },
    headers: { "Content-Type": "application/json" },
    data: {
      document: { path: documentPath, template: { data: templateData } },
    },
  };

  return axios(options);
}

async function createSigner(name, phoneNumber, birthDate, email, cpf) {
  const token = process.env.CLICKSIGN_API_TOKEN;
  const url = `${process.env.CLICKSIGN_API_URL}/signers?access_token=${token}`;

  const signerConfig = {
    auths: ["email"],
    selfie_enabled: false,
    handwritten_enabled: false,
    official_document_enabled: false,
    liveness_enabled: false,
  };

  const body = {
    signer: {
      email: email,
      phone_number: phoneNumber,
      name: name,
      documentation: cpf,
      birthday: birthDate,
      has_documentation: true,
      ...signerConfig,
    },
  };

  return axios.post(url, body, {
    headers: {
      "Content-Type": "application/json",
    },
  });
}

async function addSignerToDocument(documentKey, signerKey, signAs) {
  const token = process.env.CLICKSIGN_API_TOKEN;
  const url = `${process.env.CLICKSIGN_API_URL}/documents/${documentKey}/signers?access_token=${token}`;

  const body = {
    list: {
      document_key: documentKey,
      signer_key: signerKey,
      sign_as: signAs,
    },
  };

  return axios.post(url, body, {
    headers: {
      "Content-Type": "application/json",
    },
  });
}

module.exports = {
  createDocument,
  createSigner,
  addSignerToDocument,
};
