const express = require("express");
const app = express();
const contracts = require("../mock/contracts.json");
const dotenv = require("dotenv");
dotenv.config();

app.get("/", async function (req, res) {

});

// serve on port 3000
app.listen(3000);
